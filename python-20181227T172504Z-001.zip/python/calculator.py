import Tkinter;

buttons = [ 
	[ "1", "2", "3", "+", "&" ],
	[ "4", "5", "6", "-", "|" ],
	[ "7", "8", "9", "x", "^" ],
	[ "c", "0", "=", None, "~" ]
];

root = Tkinter.Tk();
for r in range(4):
	for c in range(5):
		if not buttons[r][c] == None:
			Tkinter.Button(root, text=buttons[r][c],
			borderwidth=1, width=3).grid(row=r,column=c);
root.mainloop();